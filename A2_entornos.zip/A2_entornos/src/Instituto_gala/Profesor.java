package Instituto_gala;

import java.util.ArrayList;

public class Profesor extends Persona {
private ArrayList<Asignatura> asignaturas;


public Profesor(String nombre, String dni) {
super(nombre, dni);
asignaturas = new ArrayList<>();
}


public void impartirAsignatura(Asignatura a) {
asignaturas.add(a);
}
}
