package Instituto_gala;

public interface Ubicable {

	void ubicar (String calle, String ciudad);
		
	
	
}
