package Instituto_gala;

import java.util.ArrayList;

public class Alumno extends Persona {
private ArrayList<Asignatura> asignaturas;


public Alumno(String nombre, String dni) {
super(nombre, dni);
asignaturas = new ArrayList<>();
}


public void matricularAsignatura(Asignatura a) {
asignaturas.add(a);
}


	public void listarAsignaturas() {
			for (Asignatura a : asignaturas) {
				System.out.println(a.getNombre());
		}
	}
}