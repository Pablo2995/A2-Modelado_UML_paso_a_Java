package Instituto_gala;
import java.util.ArrayList;
	public class Instituto {
			private String nombre;
			private ArrayList<Aula> aulas;
			private ArrayList<Profesor> profesores;


public void Centro(String nombre) {
this.setNombre(nombre);
aulas = new ArrayList<>();
profesores = new ArrayList<>();
}


public void agregarAula(Aula a) {
aulas.add(a);
}


public void agregarProfesor(Profesor p) {
profesores.add(p);
}


public String getNombre() {
	return nombre;
}


public void setNombre(String nombre) {
	this.nombre = nombre;
}
}