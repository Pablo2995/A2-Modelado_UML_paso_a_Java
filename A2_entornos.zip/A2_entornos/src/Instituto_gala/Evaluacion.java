package Instituto_gala;

public class Evaluacion {
		private String descripcion;
		private double nota;


	public Evaluacion(String descripcion, double nota) {
		this.setDescripcion(descripcion);
		this.setNota(nota);
		}


	public String getDescripcion() {
		return descripcion;
	}


	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}


	public double getNota() {
		return nota;
	}


	public void setNota(double nota) {
		this.nota = nota;
	}
}
