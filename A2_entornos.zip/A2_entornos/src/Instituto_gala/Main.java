package Instituto_gala;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			Instituto instituto = new Instituto();


			Aula aula1 = new Aula(101, 30);
			instituto.agregarAula(aula1);


			Profesor prof = new Profesor("María", "123A");
			instituto.agregarProfesor(prof);


			Alumno alumno = new Alumno("Carlos", "456B");
			Asignatura prog = new Asignatura("Programación", prof);


			alumno.matricularAsignatura(prog);
			prof.impartirAsignatura(prog);


			prog.agregarEvaluacion(new Evaluacion("Examen 1", 8.5));
			
	}
}



