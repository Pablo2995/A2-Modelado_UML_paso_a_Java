package Instituto_gala;

import java.util.ArrayList;

public class Asignatura {
private String nombre;
private Profesor profesor;
private ArrayList<Evaluacion> evaluaciones;


public Asignatura(String nombre, Profesor profesor) {
this.nombre = nombre;
this.setProfesor(profesor);
evaluaciones = new ArrayList<>();
}


public String getNombre() {
return nombre;
}


public void agregarEvaluacion(Evaluacion e) {
evaluaciones.add(e);
}


public Profesor getProfesor() {
	return profesor;
}


public void setProfesor(Profesor profesor) {
	this.profesor = profesor;
}
}