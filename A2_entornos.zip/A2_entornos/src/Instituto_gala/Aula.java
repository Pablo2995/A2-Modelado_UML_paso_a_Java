package Instituto_gala;

public class Aula {
private int numero;
private int capacidad;


public Aula(int numero, int capacidad) {
this.setNumero(numero);
this.setCapacidad(capacidad);
}


public int getNumero() {
	return numero;
}


public void setNumero(int numero) {
	this.numero = numero;
}


public int getCapacidad() {
	return capacidad;
}


public void setCapacidad(int capacidad) {
	this.capacidad = capacidad;
}
}

